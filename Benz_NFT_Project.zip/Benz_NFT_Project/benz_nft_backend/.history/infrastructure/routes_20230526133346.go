package infrastructure

import (
    "net/http"
    "github.com/gin-gonic/gin"
	cors "github.com/rs/cors/wrapper/gin"
)

//GinRouter -> Gin Router
type GinRouter struct {
    Gin *gin.Engine
}

func corsMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
		c.Writer.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE")
		c.Writer.Header().Set("Access-Control-Allow-Headers", "Origin, Content-Type")
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(http.StatusOK)
			return
		}
		c.Next()
	}
}

//NewGinRouter all the routes are defined here
func NewGinRouter() GinRouter {
    httpRouter := gin.Default()
	httpRouter.Use(cors.Default())

	// Create a new CORS handler using cors.Default()
	// corsHandler := cors.Default()
	// httpRouter.Use(func(c *gin.Context) {
	// 	corsHandler.HandlerFunc(c.Writer, c.Request)
	// 	c.Next()
	// })	
    httpRouter.GET("/", func(c *gin.Context) {
        c.JSON(http.StatusOK, gin.H{"data": "Backend Up and Running..."})
    })
    return GinRouter{
        Gin: httpRouter,
    }

}