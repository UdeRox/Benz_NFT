package main

import (
    "benzNft/api/controller"
    "benzNft/api/repository"
    "benzNft/api/routes"
    "benzNft/api/service"
    "benzNft/infrastructure"
    "benzNft/models"
    "github.com/gin-gonic/gin"
    "net/http"
)

func init() {
    infrastructure.LoadEnv()
}
func corsMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
		c.Writer.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE")
		c.Writer.Header().Set("Access-Control-Allow-Headers", "Origin, Content-Type")
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(http.StatusOK)
			return
		}
		c.Next()
	}
}

func main() {
  router := infrastructure.NewGinRouter() //router has been initialized and configured
  ownerRoute.Use(corsMiddleware())

    db := infrastructure.NewDatabase() // databse has been initialized and configured
    // postRepository := repository.NewPostRepository(db) // repository are being setup
    // postService := service.NewPostService(postRepository) // service are being setup
    // postController := controller.NewPostController(postService) // controller are being set up
    // postRoute := routes.NewPostRoute(postController, router) // post routes are initialized
    ownerRepository := repository.NewOwnerRepository(db) // repository are being setup
    ownerService := service.NewOwnerService(ownerRepository) // service are being setup
    ownerController := controller.NewOwnerController(ownerService) // controller are being set up
    ownerRoute := routes.NewOwnerRoute(ownerController, router) // post routes are initialized
    ownerRoute.Setup() // post routes are being setup

    db.DB.AutoMigrate(&models.Owner{}) // migrating Post model to datbase table
    router.Gin.Run(":8000") //server started on 8000 port
}