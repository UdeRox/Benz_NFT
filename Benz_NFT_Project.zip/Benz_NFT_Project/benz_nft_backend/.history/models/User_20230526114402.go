package models

type Post struct {
	ID int	
}