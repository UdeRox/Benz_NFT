package models

type Owner struct {
	ID int64	
}