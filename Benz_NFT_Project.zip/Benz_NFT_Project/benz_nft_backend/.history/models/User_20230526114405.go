package models

type Post struct {
	ID int64	
}