package models

type Post struct {
	
}