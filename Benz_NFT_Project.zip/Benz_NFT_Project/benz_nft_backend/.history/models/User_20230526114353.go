package models

type Post struct {
	I	
}