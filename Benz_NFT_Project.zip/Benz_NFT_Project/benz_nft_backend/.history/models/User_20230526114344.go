package models

type Post str