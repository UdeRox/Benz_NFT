package models

type User struct {
	ID int64	
}