import { HardhatUserConfig } from "hardhat/config";
import "@nomicfoundation/hardhat-toolbox";

const config: H ardhatUserConfig = {
  solidity: "0.8.18",
};

export default config;
