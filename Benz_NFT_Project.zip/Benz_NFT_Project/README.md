# Sample Hardhat Project



Steps to deploy the Smartcontract locally
> yarn install 

> npx hardhat node (to start local hardhat node)
	
	Defailt validity period of the contract is 30 days, to change the validity period please update in the deployment script.

> npx hardhat run scripts/deploy.ts --network localhost (this will deploy the contract to local node, please get the deployed address of the contract to update in the frontend propety file)


This project demonstrates a basic Hardhat use case. It comes with a sample contract, a test for that contract, and a script that deploys that contract.

Try running some of the following tasks:

Front End 
 npm install -g http-server
 http-server -p 3000
 



```shell
npx hardhat help
npx hardhat test
REPORT_GAS=true npx hardhat test
npx hardhat node
npx hardhat run scripts/deploy.ts
```
